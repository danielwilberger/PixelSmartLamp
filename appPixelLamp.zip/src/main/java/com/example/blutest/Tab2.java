package com.example.blutest;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Tab2#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Tab2 extends Fragment {

    ImageButton imbtnOnOff, imbtnMoon, imbtnFire, imbtnJujuba, imbtnRainbow, imbtnRespiro,imbtnMyColor;
    SeekBar seekBarPotVal;
    int pot_val = 10;
    String last_command_sent = "k";

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Tab2() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Tab2.
     */
    // TODO: Rename and change types and number of parameters
    public static Tab2 newInstance(String param1, String param2) {
        Tab2 fragment = new Tab2();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View v = inflater.inflate(R.layout.fragment_tab2, container, false);

         // BUTTON LIGHTS ON/OFF
         imbtnOnOff = (ImageButton) v.findViewById(R.id.imageButtonOnOff);
         imbtnOnOff.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 ((MainActivity)getActivity()).sendCommandToBT("m");
             }
         });

        // BUTTON LIGHT MODE "Moon"
        imbtnMoon = (ImageButton) v.findViewById(R.id.imageButtonMoon);
        imbtnMoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("k" + pot_val);
                last_command_sent = "moon";
            }
        });

        // BUTTON LIGHT MODE "Fireplace"
        imbtnFire = (ImageButton) v.findViewById(R.id.imageButtonFireplace);
        imbtnFire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("f" + pot_val);
                last_command_sent = "fire";
            }
        });

        // BUTTON LIGHT MODE "Jujuba"
        imbtnJujuba = (ImageButton) v.findViewById(R.id.imageButtonJujuba);
        imbtnJujuba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("u" + pot_val);
                last_command_sent = "jujuba";
            }
        });

        // BUTTON LIGHT MODE "Rainbow"
        imbtnRainbow = (ImageButton) v.findViewById(R.id.imageButtonRainbow);
        imbtnRainbow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("r" + pot_val);
                last_command_sent = "rainbow";
            }
        });

        // BUTTON LIGHT MODE "Respiro"
        imbtnRespiro = (ImageButton) v.findViewById(R.id.imageButtonRespiro);
        imbtnRespiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("s" + pot_val);
                last_command_sent = "respiro";
            }
        });

        // BUTTON LIGHT MODE "MyColor"
        imbtnMyColor = (ImageButton) v.findViewById(R.id.imageButtonMycolor);
        imbtnMyColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).sendCommandToBT("c" + pot_val);
                last_command_sent = "mycolor";
            }
        });

        // SEEKBAR

        seekBarPotVal = (SeekBar) v.findViewById(R.id.seekBar2);
        seekBarPotVal.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                pot_val = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                switch (last_command_sent){
                    case "moon":
                        imbtnMoon.callOnClick();
                        break;
                    case "fire":
                        imbtnFire.callOnClick();
                        break;
                    case "jujuba":
                        imbtnJujuba.callOnClick();
                        break;
                    case "rainbow":
                        imbtnRainbow.callOnClick();
                        break;
                    case "respiro":
                        imbtnRespiro.callOnClick();
                        break;
                    case "mycolor":
                        imbtnMyColor.callOnClick();
                        break;
                    default:
                        break;
                }

            }
        });




        return v;


    }
}