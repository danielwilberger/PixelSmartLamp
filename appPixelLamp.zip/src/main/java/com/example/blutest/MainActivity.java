package com.example.blutest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TimePicker;

import com.google.android.material.tabs.TabLayout;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothAdapter meuBluetoothAdapter = null;
    BluetoothDevice meuArduino = null;
    BluetoothSocket meuSocket = null;


    boolean conexao = false;
    private static final int SOLICITA_ATIVACAO_BLUETOOTH = 1;
    private static final int SOLICITA_CONEXAO_BLUETOOTH = 2;

    ConnectedThread connectedThread;

    private static String MAC = null;
    private static String NOME_DEVICE = null;

    UUID MEU_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    /*Button btnConectar, btnMudarLuz, btnLuzDown, btnRelogio, btnOnOff, btnNovoAlarme, btnMoon;
    TimePicker timePicker1;
    TextView TV_HoraSelecionada;
    SeekBar seekBarPotVal;*/

    /*int pot_val = 10;
    String ultimo_comando_enviado;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        tabLayout.addTab(tabLayout.newTab().setText("Conectar"));
        tabLayout.addTab(tabLayout.newTab().setText("Luminária"));
        tabLayout.addTab(tabLayout.newTab().setText("Relógio"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(),tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.setOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        /*timePicker1 = (TimePicker) findViewById(R.id.timePicker1);
        timePicker1.setIs24HourView(true);
        TV_HoraSelecionada = (TextView) findViewById(R.id.textViewHoraSelecionada);

        //seekBarPotVal = (SeekBar) findViewById(R.id.seekBar);*/



        ////////////////////////////////////////////////////////////////////////////////////////////
        // Botões

        //btnConectar = (Button) findViewById(R.id.buttonConectar2);
        /*btnMudarLuz = (Button) findViewById(R.id.buttonMudarLuz);
        btnLuzDown = (Button) findViewById(R.id.buttonMudarLuz2);
        btnRelogio = (Button) findViewById(R.id.buttonRelogio);
        btnOnOff = (Button) findViewById(R.id.buttonOnOff);
        btnNovoAlarme = (Button) findViewById(R.id.buttonNovoAlarme);
        btnMoon = (Button) findViewById(R.id.buttonMoon);*/




        ////////////////////////////////////////////////////////////////////////////////////////////





        /*////////////////////////////////////////////////////////////////////////////////////////////
        // OnClickListeners DOS BOTÕES



        btnNovoAlarme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int hour = timePicker1.getHour();
                int minute = timePicker1.getMinute();

                if (conexao){
                    String comandoEnviar = formataComando("e" + hour + minute);
                    TV_HoraSelecionada.setText(comandoEnviar);
                    connectedThread.enviar(comandoEnviar);
                    ultimo_comando_enviado = "e";
                    Toast.makeText(getApplicationContext(),"Alarme ajustado para " + hour + ":" + minute + "h",Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(getApplicationContext(),"Bluetooth não está conectado",Toast.LENGTH_LONG).show();
                }

            }
        });



*/
    ////////////////////////////////////////////////////////////////////////////////////////////

    }

    public boolean connectToBTmodule(){

        boolean status_BT = false;

               if (conexao){
                   // Disconnect:
                   try {
                       meuSocket.close();
                       conexao = false;
                       Toast.makeText(getApplicationContext(),"O Bluetooth foi desconectado",Toast.LENGTH_LONG).show();
                       status_BT = false;

                   } catch (IOException erro){
                       Toast.makeText(getApplicationContext(),"Ocorreu um erro" + erro,Toast.LENGTH_LONG).show();
                   }

               } else {
                   // Connect:
                   Intent abreLista = new Intent(MainActivity.this,ListaDispositivos.class);
                   startActivityForResult(abreLista,SOLICITA_CONEXAO_BLUETOOTH);
                   status_BT = true;
               }

        return status_BT;
    }



    public void sendCommandToBT (String comando){

        String comandoFormatado = "<" + comando + ">";

        if (conexao){
            connectedThread.enviar(comandoFormatado);
            //Toast.makeText(getApplicationContext(),comandoFormatado,Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(),"Bluetooth não está conectado",Toast.LENGTH_LONG).show();
        }



    }

    ////////////////////////////////////////////////////////////////////////////////////////////
    // PARA VERIFICAR SE O DISPOSITIVO POSSUI BLUETOOTH E ATIVAR ELE

    public void checkBTavailability() {

        meuBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if( meuBluetoothAdapter == null){
            Toast.makeText(getApplicationContext(),"Seu dispositivo não possui Bluetooth",Toast.LENGTH_LONG).show();
        } else if(!meuBluetoothAdapter.isEnabled()){
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent,SOLICITA_ATIVACAO_BLUETOOTH);
        }


    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        ////////////////////////////////////////////////////////////////////////////////////////////
        // Depois de verificar se bluetooth está ativado ou não, avisa o usuário e fecha o app se não tiver sido ativado
        switch (requestCode){

            case SOLICITA_ATIVACAO_BLUETOOTH:
                if(resultCode == Activity.RESULT_OK){
                    Toast.makeText(getApplicationContext(),"O Bluetooth foi ativado",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(),"O Bluetooth não foi ativado. O app será encerrado.",Toast.LENGTH_LONG).show();
                    finish();
                }
                break;

            case SOLICITA_CONEXAO_BLUETOOTH:
                if(resultCode == Activity.RESULT_OK){

                    String RECEBIDOS = data.getExtras().getString(ListaDispositivos.NOME_E_MAC);
                    MAC = (RECEBIDOS).substring(RECEBIDOS.length() - 17);
                    NOME_DEVICE = RECEBIDOS.substring(0, RECEBIDOS.length() - 17);

                   // NOME_DEVICE = data.getExtras().getString(ListaDispositivos.NOME);
                    //Toast.makeText(getApplicationContext(),"MAC FINAL: " + MAC,Toast.LENGTH_LONG).show();
                    meuArduino = meuBluetoothAdapter.getRemoteDevice(MAC);

                    try {
                        meuSocket = meuArduino.createRfcommSocketToServiceRecord(MEU_UUID);

                        meuSocket.connect();

                        conexao = true;

                        connectedThread = new ConnectedThread(meuSocket);
                        connectedThread.start();

                        //btnConectar.setText("Desconectar");

                        Toast.makeText(getApplicationContext(),"Você foi conectado com: " + NOME_DEVICE,Toast.LENGTH_LONG).show();

                    } catch (IOException erro){
                        Toast.makeText(getApplicationContext(),"Ocorreu um erro: " + erro,Toast.LENGTH_LONG).show();
                        conexao = false;
                    }

                } else {
                    Toast.makeText(getApplicationContext(),"Falha ao obter o MAC",Toast.LENGTH_LONG).show();
                }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////

    }



    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private byte[] mmBuffer; // mmBuffer store for the stream

        public ConnectedThread(BluetoothSocket socket) {

            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            // Get the input and output streams; using temp objects because
            // member streams are final.
            try {
                tmpIn = socket.getInputStream();
            } catch (IOException e) {

            }
            try {
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {

            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            mmBuffer = new byte[1024];
            int numBytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs.
           /* while (true) {
                try {
                    // Read from the InputStream.
                    numBytes = mmInStream.read(mmBuffer);
                    // Send the obtained bytes to the UI activity.
                   // Message readMsg = handler.obtainMessage(
                    //        MessageConstants.MESSAGE_READ, numBytes, -1,
                    //        mmBuffer);
                   // readMsg.sendToTarget();
                } catch (IOException e) {

                    break;
                }
            }*/
        }

        // Call this from the main activity to send data to the remote device.
        public void enviar(String dadosEnviar) {

            byte[] msgBuffer = dadosEnviar.getBytes();

            try {
                mmOutStream.write(msgBuffer);
            } catch (IOException e) {

            }
        }


    }






}